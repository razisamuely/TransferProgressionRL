import os
import json
from pathlib import Path
import numpy as np
from src.section1.agents.actor_critic_agent import ActorCriticAgent
import torch
import torch.nn as nn
torch.autograd.set_detect_anomaly(True)
class ProgressiveActorNetwork(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim, model_1, model_2):
        super(ProgressiveActorNetwork, self).__init__()
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model_1 = model_1.to(self.device)
        self.model_2 = model_2.to(self.device)
        self.freeze_model(self.model_1)
        self.freeze_model(self.model_2)
        self.main_network = self.create_network(input_dim, hidden_dim, output_dim).to(self.device)
        self.adapter_1_layer1 = self._create_adapter(hidden_dim).to(self.device)
        self.adapter_1_layer2 = self._create_adapter(hidden_dim).to(self.device)
        self.adapter_2_layer1 = self._create_adapter(hidden_dim).to(self.device)
        self.adapter_2_layer2 = self._create_adapter(hidden_dim).to(self.device)

    def freeze_model(self, model):
        for param in model.parameters():
            param.requires_grad = False

    def create_network(self, input_dim, hidden_dim, output_dim):
        return nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, output_dim),
        )

    def _create_adapter(self, hidden_dim):
        return torch.nn.Sequential(
            torch.nn.Linear(hidden_dim, hidden_dim // 2),
            torch.nn.ReLU(),
            torch.nn.Linear(hidden_dim // 2, hidden_dim),
        )

    def forward(self, state):
        h1_target = self.main_network[0](state)
        h1_target = self.main_network[1](h1_target)  # ReLU activation
        h1_model_1 = self.model_1[0](state)
        h1_model_1 = self.model_1[1](h1_model_1)  # ReLU activation
        h1_model_2 = self.model_2[0](state)
        h1_model_2 = self.model_2[1](h1_model_2)  # ReLU activation

        # Avoid in-place operations
        h1_target = h1_target + self.adapter_1_layer1(h1_model_1)
        h1_target = h1_target + self.adapter_2_layer1(h1_model_2)

        h2_target = self.main_network[2](h1_target)
        h2_target = self.main_network[3](h2_target)  # ReLU activation
        h2_model_1 = self.model_1[2](h1_model_1)
        h2_model_1 = self.model_1[3](h2_model_1)  # ReLU activation
        h2_model_2 = self.model_2[2](h1_model_2)
        h2_model_2 = self.model_2[3](h2_model_2)  # ReLU activation

        # Avoid in-place operations
        h2_target = h2_target + self.adapter_1_layer2(h2_model_1)
        h2_target = h2_target + self.adapter_2_layer2(h2_model_2)

        output = self.main_network[4](h2_target)
        return output


class ProgressiveCriticNetwork(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim, model_1, model_2):
        super(ProgressiveCriticNetwork, self).__init__()
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model_1 = model_1.to(self.device)
        self.model_2 = model_2.to(self.device)
        self.freeze_model(self.model_1)
        self.freeze_model(self.model_2)
        self.main_network = self.create_network(input_dim, hidden_dim, output_dim).to(self.device)
        self.adapter_1_layer1 = self._create_adapter(hidden_dim).to(self.device)
        self.adapter_1_layer2 = self._create_adapter(hidden_dim).to(self.device)
        self.adapter_2_layer1 = self._create_adapter(hidden_dim).to(self.device)
        self.adapter_2_layer2 = self._create_adapter(hidden_dim).to(self.device)

    def freeze_model(self, model):
        for param in model.parameters():
            param.requires_grad = False
        model.eval()
        
    def create_network(self, input_dim, hidden_dim, output_dim):
        return nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, output_dim),
        )

    def _create_adapter(self, hidden_dim):
        return nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU()
        )

    def forward(self, state):
        h1_target = self.main_network[0](state)
        h1_target = self.main_network[1](h1_target)  # ReLU activation
        h1_model_1 = self.model_1[0](state)
        h1_model_1 = self.model_1[1](h1_model_1)  # ReLU activation
        h1_model_2 = self.model_2[0](state)
        h1_model_2 = self.model_2[1](h1_model_2)  # ReLU activation

        # Avoid in-place operations
        h1_target = h1_target + self.adapter_1_layer1(h1_model_1)
        h1_target = h1_target + self.adapter_2_layer1(h1_model_2)

        h2_target = self.main_network[2](h1_target)
        h2_target = self.main_network[3](h2_target)  # ReLU activation
        h2_model_1 = self.model_1[2](h1_model_1)
        h2_model_1 = self.model_1[3](h2_model_1)  # ReLU activation
        h2_model_2 = self.model_2[2](h1_model_2)
        h2_model_2 = self.model_2[3](h2_model_2)  # ReLU activation

        # Avoid in-place operations
        h2_target = h2_target + self.adapter_1_layer2(h2_model_1)
        h2_target = h2_target + self.adapter_2_layer2(h2_model_2)

        output = self.main_network[4](h2_target)
        return output

class ProgressiveActorCriticAgent(ActorCriticAgent):
    MAX_INPUT_DIM = 6
    MAX_OUTPUT_DIM = 3

    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        gamma: float,
        learning_rate_actor: float,
        learning_rate_critic: float,
        agent_1: ActorCriticAgent,
        agent_2: ActorCriticAgent,
        models_dir: str = None,
        entropy_weight: float = 0.1,
    ):
        super(ProgressiveActorCriticAgent, self).__init__(
            input_dim=input_dim,
            output_dim=output_dim,
            gamma=gamma,
            learning_rate_actor=learning_rate_actor,
            learning_rate_critic=learning_rate_critic,
            models_dir=models_dir,
            entropy_weight=entropy_weight,
        )
        self.agent_1 = agent_1
        self.agent_2 = agent_2
        self.actor_model = ProgressiveActorNetwork(
            input_dim=self.MAX_INPUT_DIM,
            hidden_dim=128,
            output_dim=self.MAX_OUTPUT_DIM,
            model_1=self.agent_1.actor_model,
            model_2=self.agent_2.actor_model,
        ).to(self.device)
        self.critic_model = ProgressiveCriticNetwork(
            input_dim=self.MAX_INPUT_DIM,
            hidden_dim=128,
            output_dim=1,
            model_1=self.agent_1.critic_model,
            model_2=self.agent_2.critic_model,
        ).to(self.device)
        self.actor_optimizer = torch.optim.Adam(
            self.actor_model.parameters(), lr=self.learning_rate_actor
        )
        self.critic_optimizer = torch.optim.Adam(
            self.critic_model.parameters(), lr=self.learning_rate_critic
        )

        if models_dir:
            Path(models_dir).mkdir(parents=True, exist_ok=True)


    def save_models(self, episode=None):
        save_path = self.models_dir
        if episode is not None:
            save_path = os.path.join(save_path, f"episode_{episode}")
            os.makedirs(save_path, exist_ok=True)

        actor_path = os.path.join(save_path, "actor.pth")
        torch.save(
            {
                "model_state_dict": self.actor_model.state_dict(),
                "optimizer_state_dict": self.actor_optimizer.state_dict(),
                "input_dim": int(self.input_dim),
                "output_dim": int(self.output_dim),
                "learning_rate": float(self.learning_rate_actor),
            },
            actor_path,
        )

        critic_path = os.path.join(save_path, "critic.pth")
        torch.save(
            {
                "model_state_dict": self.critic_model.state_dict(),
                "optimizer_state_dict": self.critic_optimizer.state_dict(),
                "input_dim": int(self.input_dim),
                "output_dim": 1,
                "learning_rate": float(self.learning_rate_critic),
            },
            critic_path,
        )
        hyper_params = {
            "gamma": float(self.gamma),
            "learning_rate_actor": float(self.learning_rate_actor),
            "learning_rate_critic": float(self.learning_rate_critic),
            "input_dim": int(self.input_dim),
            "output_dim": int(self.output_dim),
            "orig_input_dim": int(self.orig_input_dim),
            "orig_output_dim": int(self.orig_output_dim),
            "models_dir": str(self.models_dir),
        }
        with open(os.path.join(save_path, "hyperparameters.json"), "w") as f:
            json.dump(hyper_params, f)
